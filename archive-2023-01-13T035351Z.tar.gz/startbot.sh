echo ====================================================
echo               Start Bot Script
echo               Author : HELLSNAKES
echo ====================================================
npm start